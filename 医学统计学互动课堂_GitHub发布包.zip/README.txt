医学统计学互动课堂 —— GitHub Pages 发布目录
========================================

【文件说明】
index.html          入口页（目录，含两个课堂入口）
distributions.html  统计分布互动课堂（正态/t/χ²/F/二项/泊松/多元正态/logit/假设检验原理）
survival.html       生存分析互动课堂（KM/Log-rank/Cox/综合分析）
.nojekyll           告诉 GitHub Pages 不要用 Jekyll 处理，直接按静态文件发布
404.html            访问不存在的地址时的兜底页（即入口页）

所有页面为单文件 HTML，无任何外部依赖，可离线打开。

【如何上传到 GitHub Pages】
详见随附的操作步骤说明。
